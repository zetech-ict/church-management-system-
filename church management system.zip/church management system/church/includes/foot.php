 <!-- plugins:js -->
 <script src="assets/vendors/js/vendor.bundle.base.js"></script>
 <!-- endinject -->
 <!-- Plugin js for this page -->
 <script src="assets/vendors/chart.js/Chart.min.js"></script>
 <!-- End plugin js for this page -->
 <!-- inject:js -->
 <script src="assets/js/off-canvas.js"></script>
 <script src="assets/js/hoverable-collapse.js"></script>
 <script src="assets/js/misc.js"></script>
 <!-- endinject -->
 <!-- Custom js for this page -->
 <!--  <script src="assets/js/dashboard.js"></script> -->
 <script src="assets/js/todolist.js"></script>
 <script src="assets/js/file-upload.js"></script>
 <!-- End custom js for this page -->


 <!-- DataTables -->
<!--  <script src="plugins/datatables/jquery.dataTables.min.js"></script>
 <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
 <script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
 <script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script> -->


 <script src="vendor2/datatables/jquery.dataTables.min.js"></script>
 <script src="vendor2/datatables/dataTables.bootstrap4.min.js"></script>

 <script src="assets2/js/jquery.cslider.js"></script>
 <script src="assets2/js/jquery.isotope.min.js"></script>
 <script src="assets2/js/fancybox/jquery.fancybox.pack.js" type="text/javascript"></script>
 <script src="assets2/js/custom.js"></script>
 

<script>
    $(document).ready(function () {
      $('#dataTable').DataTable(); // ID From dataTable 
      $('#dataTableHover').DataTable(); // ID From dataTable with Hover
    });
  </script>