﻿How to run Project
1. Download and Unzip the file on your local system copy church .
2. Put church folder inside root directory (for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

Database Configuration

Open phpmyadmin
Create Database churchdb
Import database churchdb.sql (available SQL File Folder inside zip package)

Open Your browser put inside browser “http://localhost/church”
Login Details for admin :
Username: admin
Password: 1234
